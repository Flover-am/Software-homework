
def logo_play():
    """write your code in method"""
    return
