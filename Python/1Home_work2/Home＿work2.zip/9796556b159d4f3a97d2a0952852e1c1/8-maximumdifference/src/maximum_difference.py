def cal_max_difference():
# enter your code here
    num_input = inp
