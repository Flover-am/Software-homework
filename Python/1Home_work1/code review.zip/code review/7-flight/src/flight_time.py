# 这是一个示例 Python 脚本。

# 按 Shift+F10 执行或将其替换为您的代码。
# 按 双击 Shift 在所有地方搜索类、文件、工具窗口、操作和设置。
import re


def time_solve(h, m, s, day):
    return int(3600 * h + 60 * m + s + 24 * 3600 * day)


def time_split():
    input_line = input()
    h1 = int(input_line[0:2])
    m1 = int(input_line[3:5])
    s1 = int(input_line[6:8])
    h2 = int(input_line[9:11])
    m2 = int(input_line[12:14])
    s2 = int(input_line[15:17])

    if len(input_line) > 18:
        day = int(input_line[20])
    else:
        day = 0

    return time_solve(h2, m2, s2, day) - time_solve(h1, m1, s1, 0)


def flight_calculation():
    flying_time = (time_split() + time_split()) / 2
    # print(flying_time)

    h = flying_time // 3600
    m = flying_time % 3600 // 60
    s = flying_time % 60 // 1

    print(f"{h:02.0f}:{m:02.0f}:{s:02.0f}")

    return
