
def cal_amount_of_lolipop():
    # your code here ^_^
    a, b = map(int, input().split())
    money = 10 * a + b
    print(money // 67)
    return

