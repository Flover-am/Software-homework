import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.*;
public class Literal {

    public static void main(String[] args) {
        try{
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String input = br.readLine();
            if (Pattern.matches("^'.*?'$",input)){
                System.out.println("char");
            }else if (Pattern.matches("^\\d+.*?[Ll]$",input)){
                System.out.println("long");
            }else if (Pattern.matches("^\\d+.*?[Ff]$",input)){
                System.out.println("float");
            }else if (Pattern.matches("^\\d+$",input)){
                System.out.println("integer");
            }else if (Pattern.matches("[truefals]{4,5}",input)){
                System.out.println("boolean");
            }else if (Pattern.matches("\\d+\\.\\d+",input)){
                System.out.println("double");
            }
        }catch (IOException e){
            e.printStackTrace();
        }

    }
}
