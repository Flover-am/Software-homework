import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ZTransformation {
    public static void main(String[] args) {

        int num = 0;
        StringBuilder words_in = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            words_in.append(br.readLine().toCharArray());
            num = Integer.parseInt(br.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (num == 1){
            char[] pp = words_in.toString().toCharArray();
            for (int i = 0;i < pp.length-1;i++){
                System.out.print(pp[i]+" ");
            }
            System.out.print(pp[pp.length-1]);
            return;
        }

        int len = words_in.length();
        char[][] pic = new char[num][len * 2];
        for (int i = 0; i < num; i++) {
            for (int j = 0; j < len * 2; j++) {
                pic[i][j] = ' ';
            }
        }
        String flag = "down";
        int x = 0;
        int y = 0;
        char[] words = words_in.toString().toCharArray();

        for (int place = 0; place < len; place++) {
            if (flag.equals("down")) {
                if (y == num) {
                    flag = "up";
                    place--;
                    y--;
                } else {
                    pic[y][x] = words[place];
                    y++;
                }
            } else if (flag.equals("up")) {
                if (y == 0) {
                    flag = "down";
                    place--;
                    y++;
                } else {
                    x += 2;
                    y--;
                    pic[y][x] = words[place];

                }
            }
        }
        if (words.length<num){
            num = words.length;
        }
        for (int i = 0; i < num; i++) {
            String ss = String.valueOf(pic[i]);
            System.out.println(ss.trim());
        }
    }
}
