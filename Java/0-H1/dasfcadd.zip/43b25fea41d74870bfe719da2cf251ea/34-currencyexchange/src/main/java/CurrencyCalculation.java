import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Formatter;


public class CurrencyCalculation {

    public static void main(String[] args) {
        double eur = 0D;
        double rate = 0D;
        try {
            System.out.println("How many euros are you exchanging?");
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            eur = Double.parseDouble(br.readLine());
            System.out.println("What is the exchange rate?");
            rate = Double.parseDouble(br.readLine());

        } catch (IOException e) {
            e.printStackTrace();
        }
        double dollar = eur * rate;
        Formatter formatter = new Formatter();
        formatter.format("%.2f euros at an exchange rate of %.2f is %.2f U.S. dollars.", eur, rate, dollar / 100);
        String result = formatter.toString();
        formatter.close();
        System.out.println(result);


    }

}
